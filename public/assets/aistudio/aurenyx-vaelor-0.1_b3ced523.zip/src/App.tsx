import { useEffect, useRef, useState } from 'react'
import {
  Activity, ArrowDown, ArrowUp, Atom, BookOpen, Check, ChevronDown, CircleHelp,
  Command, Copy, FileText, FolderKanban, Globe2, Menu, MessageSquare, Plus,
  Search, Settings2, ShieldCheck, Sparkles, TerminalSquare, X, Zap
} from 'lucide-react'

type Message = { id: string; role: 'user' | 'assistant'; content: string; agent?: string; time: string }
type Agent = { name: string; role: string; icon: typeof Sparkles; color: string }
const agents: Agent[] = [
  { name: 'Vaelor Core', role: 'Task orchestration', icon: Atom, color: 'violet' },
  { name: 'Aurenyx Research', role: 'Research planning & synthesis', icon: Search, color: 'blue' },
  { name: 'Vaelor Forge', role: 'Coding & technical design', icon: TerminalSquare, color: 'orange' },
  { name: 'Vaelor Knowledge', role: 'Documents & project context', icon: BookOpen, color: 'green' },
  { name: 'Vaelor Sentinel', role: 'Quality & safety review', icon: ShieldCheck, color: 'pink' }
]
const suggestions = [
  { icon: Search, title: 'Research a complex topic', text: 'Create a research plan for...' },
  { icon: TerminalSquare, title: 'Design a software project', text: 'Design a beginner-friendly architecture for...' },
  { icon: FileText, title: 'Analyze a document', text: 'Help me analyze a document about...' },
  { icon: Sparkles, title: 'Develop a strategy', text: 'Build a practical strategy for...' }
]
const now = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
const initialMessage = (): Message => ({
  id: 'welcome', role: 'assistant', agent: 'Vaelor Core', time: now(),
  content: 'Welcome to AURENYX VAELOR. I can help you plan, reason, write, and build. Choose a suggested task or tell me what you want to accomplish. For complex requests, I’ll route the task to a specialist and show you the execution status.'
})

export default function App() {
  const [messages, setMessages] = useState<Message[]>([initialMessage()])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [activeNav, setActiveNav] = useState('Chat')
  const [mobileNav, setMobileNav] = useState(false)
  const [showAgents, setShowAgents] = useState(true)
  const [status, setStatus] = useState<'checking' | 'ready' | 'setup' | 'offline'>('checking')
  const [agentActivity, setAgentActivity] = useState('Waiting for a task')
  const [lastAgent, setLastAgent] = useState('Vaelor Core')
  const [error, setError] = useState('')
  const endRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    fetch('/api/health').then(async r => {
      const d = await r.json()
      setStatus(d.configured ? 'ready' : 'setup')
    }).catch(() => setStatus('offline'))
  }, [])
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages, busy])

  async function sendMessage(raw?: string) {
    const content = (raw ?? input).trim()
    if (!content || busy) return
    setError('')
    setInput('')
    const userMsg: Message = { id: crypto.randomUUID(), role: 'user', content, time: now() }
    setMessages(prev => [...prev, userMsg])
    setBusy(true)
    setAgentActivity('Classifying task…')
    try {
      const response = await fetch('/api/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: content, history: messages.filter(m => m.id !== 'welcome').slice(-8).map(m => ({ role: m.role, content: m.content })) })
      })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'The request could not be completed.')
      setLastAgent(data.agent || 'Vaelor Core')
      setAgentActivity(`Completed with ${data.agent || 'Vaelor Core'}`)
      setMessages(prev => [...prev, {
        id: crypto.randomUUID(), role: 'assistant', content: data.reply,
        agent: data.agent || 'Vaelor Core', time: now()
      }])
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Unexpected error.'
      setError(msg)
      setAgentActivity('Task failed — see details')
    } finally { setBusy(false) }
  }

  function newChat() {
    setMessages([initialMessage()]); setInput(''); setError(''); setAgentActivity('Waiting for a task')
    setActiveNav('Chat'); setMobileNav(false)
  }

  const navItems = [
    { name: 'Chat', icon: MessageSquare },
    { name: 'Projects', icon: FolderKanban },
    { name: 'Agents', icon: Atom },
    { name: 'Knowledge', icon: BookOpen },
    { name: 'Tasks', icon: Activity },
    { name: 'Settings', icon: Settings2 }
  ]

  return (
    <div className="app-shell">
      {mobileNav && <button className="mobile-scrim" aria-label="Close menu" onClick={() => setMobileNav(false)} />}
      <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}>
        <div className="brand">
          <div className="brand-mark"><Atom size={24} strokeWidth={1.7}/></div>
          <div><div className="brand-name">AURENYX</div><div className="brand-sub">V A E L O R</div></div>
          <button className="icon-button close-mobile" onClick={() => setMobileNav(false)} aria-label="Close navigation"><X size={18}/></button>
        </div>
        <button className="new-chat" onClick={newChat}><Plus size={17}/> New conversation <span>⌘ K</span></button>
        <div className="nav-label">WORKSPACE</div>
        <nav>
          {navItems.map(item => {
            const Icon = item.icon
            return <button key={item.name} className={`nav-item ${activeNav === item.name ? 'nav-active' : ''}`}
              onClick={() => { setActiveNav(item.name); setMobileNav(false) }}>
              <Icon size={17}/><span>{item.name}</span>
              {item.name === 'Agents' && <span className="nav-count">5</span>}
            </button>
          })}
        </nav>
        <div className="sidebar-spacer"/>
        <div className="plan-card">
          <div className="plan-top"><Zap size={15}/><span>VAELOR CORE</span><span className="plan-free">FREE</span></div>
          <p>Prototype mode. Requests use your configured provider quota.</p>
          <div className="quota-track"><div/></div>
          <span className="quota-caption">Usage depends on your model provider</span>
        </div>
        <div className="profile-row">
          <div className="avatar">A</div><div className="profile-text"><strong>Workspace</strong><span>Personal instance</span></div>
          <button className="icon-button" aria-label="Workspace help" title="Personal prototype"><CircleHelp size={17}/></button>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="top-left">
            <button className="icon-button menu-button" onClick={() => setMobileNav(true)} aria-label="Open navigation"><Menu size={20}/></button>
            <div className="breadcrumb"><span>Workspace</span><span className="crumb-slash">/</span><strong>{activeNav}</strong></div>
          </div>
          <div className="top-actions">
            <div className={`connection-pill ${status}`}><span className="status-dot"/>{status === 'ready' ? 'Model connected' : status === 'setup' ? 'Setup required' : status === 'offline' ? 'Backend offline' : 'Checking backend'}</div>
            <button className="icon-button" onClick={() => setShowAgents(v => !v)} title="Toggle agent panel" aria-label="Toggle agent panel"><Activity size={18}/></button>
          </div>
        </header>

        {activeNav === 'Chat' ? <div className="chat-layout">
          <section className="conversation">
            <div className="conversation-scroll">
              {messages.length === 1 ? <div className="welcome-wrap">
                <div className="eyebrow"><span className="eyebrow-line"/> INTELLIGENCE, ORCHESTRATED</div>
                <div className="hero-emblem"><div className="emblem-ring ring-one"/><div className="emblem-ring ring-two"/><Atom size={42} strokeWidth={1.2}/><span className="emblem-spark">✦</span></div>
                <h1>Think beyond<br/><span>the ordinary.</span></h1>
                <p className="hero-copy">A workspace for research, reasoning, creation, and discovery.</p>
                <div className="suggestion-grid">
                  {suggestions.map(s => { const Icon = s.icon; return <button className="suggestion-card" key={s.title} onClick={() => { setInput(s.text); inputRef.current?.focus() }}>
                    <div className="suggestion-icon"><Icon size={18}/></div><strong>{s.title}</strong><span>{s.text}</span><ArrowUp className="suggestion-arrow" size={15}/>
                  </button> })}
                </div>
              </div> : <div className="message-list">
                {messages.filter(m => m.id !== 'welcome').map(m => <div className={`message-row ${m.role}`} key={m.id}>
                  <div className={`message-avatar ${m.role === 'assistant' ? 'assistant-avatar' : ''}`}>{m.role === 'assistant' ? <Atom size={17}/> : 'A'}</div>
                  <div className="message-body">
                    <div className="message-meta"><strong>{m.role === 'assistant' ? (m.agent || 'VAELOR') : 'You'}</strong><span>{m.time}</span></div>
                    <div className="message-content">{m.content}</div>
                    {m.role === 'assistant' && <button className="copy-button" onClick={() => navigator.clipboard?.writeText(m.content)}><Copy size={13}/> Copy response</button>}
                  </div>
                </div>)}
                {busy && <div className="message-row assistant"><div className="message-avatar assistant-avatar"><Atom size={17}/></div><div className="message-body"><div className="message-meta"><strong>{lastAgent}</strong><span>Working</span></div><div className="typing"><span/><span/><span/></div><div className="typing-label">{agentActivity}</div></div></div>}
                <div ref={endRef}/>
              </div>}
            </div>
            <div className="composer-wrap">
              {error && <div className="error-banner"><CircleHelp size={16}/><span>{error}</span><button onClick={() => setError('')} aria-label="Dismiss error"><X size={15}/></button></div>}
              {status === 'setup' && <div className="setup-note"><ShieldCheck size={15}/> Backend is online, but the model key is not configured yet. Add it on the server to enable real AI responses.</div>}
              {status === 'offline' && <div className="setup-note warning"><Activity size={15}/> Backend unavailable. Start the API server or configure the hosted backend URL.</div>}
              <div className="composer">
                <textarea ref={inputRef} value={input} onChange={e => setInput(e.target.value)} placeholder="Ask Vaelor anything…" rows={1}
                  onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void sendMessage() } }} />
                <div className="composer-bottom"><div className="composer-hints"><Sparkles size={14}/><span>Multi-agent orchestration</span><span className="hint-divider">·</span><span>Bounded execution</span></div>
                  <button className="send-button" disabled={!input.trim() || busy} onClick={() => void sendMessage()} aria-label="Send message">{busy ? <span className="send-spinner"/> : <ArrowUp size={18}/>}</button>
                </div>
              </div>
              <div className="disclaimer">Vaelor can make mistakes. Verify important information and sources.</div>
            </div>
          </section>

          {showAgents && <aside className="agent-panel">
            <div className="panel-heading"><div><span className="panel-kicker">SYSTEM STATUS</span><h3>Agent network</h3></div><button className="icon-button panel-close" onClick={() => setShowAgents(false)} aria-label="Close agent panel"><X size={17}/></button></div>
            <div className="network-card"><div className="network-visual"><div className="network-orbit orbit-a"/><div className="network-orbit orbit-b"/><div className="network-core"><Atom size={27}/></div><span className="node node-a"/><span className="node node-b"/><span className="node node-c"/><span className="node node-d"/></div><div className="network-title">VAELOR CORE <span className="live-tag"><span/> SYSTEM</span></div><p>Task orchestration and controlled delegation</p></div>
            <div className="panel-section-title">SPECIALISTS <span>04</span></div>
            <div className="agent-list">{agents.slice(1).map(a => { const Icon = a.icon; return <div className="agent-item" key={a.name}><div className={`agent-icon ${a.color}`}><Icon size={16}/></div><div className="agent-info"><strong>{a.name}</strong><span>{a.role}</span></div><span className="idle-dot" title="Idle"/></div> })}</div>
            <div className="activity-card"><div className="activity-head"><span>RECENT ACTIVITY</span><Activity size={14}/></div><div className="activity-line"><span className={`activity-indicator ${busy ? 'active' : ''}`}/><div><strong>{agentActivity}</strong><span>{busy ? 'Current task' : 'No active tasks'}</span></div></div></div>
            <div className="security-foot"><ShieldCheck size={16}/><div><strong>Safety controls enabled</strong><span>Bounded steps · Server-side model calls</span></div></div>
          </aside>}
        </div> : <section className="placeholder-page">
          <div className="placeholder-icon">{activeNav === 'Projects' ? <FolderKanban/> : activeNav === 'Agents' ? <Atom/> : activeNav === 'Knowledge' ? <BookOpen/> : activeNav === 'Tasks' ? <Activity/> : <Settings2/>}</div>
          <div className="eyebrow">AURENYX VAELOR 0.1</div><h2>{activeNav}</h2>
          <p>{activeNav === 'Projects' ? 'Project workspaces are planned for the next milestone.' : activeNav === 'Agents' ? 'Agent definitions are visible in the network panel. Detailed agent controls are coming next.' : activeNav === 'Knowledge' ? 'Document indexing and persistent knowledge are not connected in this first slice.' : activeNav === 'Tasks' ? 'Task history will appear here after persistent storage is configured.' : 'Configure the model provider using server-side environment variables. Never paste a secret into the browser.'}</p>
          {activeNav === 'Settings' && <div className="settings-card"><div className="setting-row"><div><strong>Model gateway</strong><span>Server-side provider configuration</span></div><span className={`settings-status ${status}`}>{status === 'ready' ? 'Connected' : status === 'setup' ? 'Needs key' : status === 'offline' ? 'Offline' : 'Checking'}</span></div><div className="setting-row"><div><strong>Provider</strong><span>Gemini API (configurable)</span></div><span className="setting-value">Gemini</span></div><div className="setting-row"><div><strong>Execution limit</strong><span>Maximum model calls per request</span></div><span className="setting-value">4 calls</span></div><div className="setting-row"><div><strong>API keys</strong><span>Must remain on the backend</span></div><ShieldCheck size={18} className="safe-icon"/></div></div>}
          <button className="primary-button" onClick={() => { setActiveNav('Chat'); setMobileNav(false) }}>Return to chat <ArrowDown size={16}/></button>
        </section>}
        <footer className="app-footer"><span>© 2026 AURENYX VAELOR</span><span><span className="footer-dot"/> Prototype v0.1</span><span>Built for clarity, designed for trust.</span></footer>
      </main>
    </div>
  )
}
